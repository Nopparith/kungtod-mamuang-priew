from flask import Flask
import requests

app = Flask(__name__)

@app.route('/')
def call_api2():
    print("API1: รับคำขอจากผู้ใช้")
    try:
        response = requests.get("http://api2:5001/")
        print("API1: ได้รับคำตอบจาก API2")
        return f"API1 -> API2 ตอบกลับว่า: {response.text}"
    except Exception as e:
        print("API1: เกิดข้อผิดพลาดตอนเรียก API2")
        return f"Error contacting API2: {str(e)}"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
